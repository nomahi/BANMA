rmu <- function(y,S,rtau2){

N <- dim(y)[1]
p <- dim(y)[2]

B <- length(rtau2)
r2 <- rtau2

mu.b <- tnew.b <- matrix(numeric(B*p),B)

q10 <- as.numeric(round(quantile(1:B,.1*1:10)))
count <- 10

for(b in 1:B){

	g <- r2[b]

	G <- gmat(g,(g/2),p)
	
	C2 <- 1
	C3 <- 0
	C4 <- numeric(p)
	C5 <- matrix(numeric(p*p),p)
  
	for(i in 1:N){
      
      yi <- as.vector(y[i,])
      wi <- which(is.na(yi)==FALSE)
      pl <- length(wi)
      
      Si <- vmat(S[i,], p)
      
      yi <- yi[wi]
      Si <- pmat(Si,wi)
      Gi <- pmat(G,wi)
      
      A2 <- det(Gi+Si)^-0.5 
	  A3 <- t(yi)%*%ginv(Gi+Si)%*%yi
      A4 <- ginv(Gi + Si)%*%yi
      A5 <- ginv(Gi + Si)
	  
	  C2 <- C2*A2
	  C3 <- C3 + A3
	  C4 <- C4 + ivec(A4,wi,p)
	  C5 <- C5 + imat(A5,wi,p)
            
	}
    
	mu2 <- t(C4)%*%ginv(C5)
	Phi2 <- ginv(C5)
	
	Phi3 <- ginv(C5) + G
	
	mu.b[b,] <- mvrnorm(1,mu2,Phi2)
	tnew.b[b,] <- mvrnorm(1,mu2,Phi3)
	
	if(sum(b==q10)>0){
		print(paste0("The ",count," percents of the posterior sampling is completed."))
		count <- count + 10
	}

}

R1 <- apply(mu.b,2,mean)
R2 <- apply(mu.b,2,sd)
R3 <- R4 <- numeric(p)
for(i in 1:p)	R3[i] <- quantile(mu.b[,i],0.025)
for(i in 1:p)	R4[i] <- quantile(mu.b[,i],0.975)

R5 <- apply(tnew.b,2,mean)
R6 <- apply(tnew.b,2,sd)
R7 <- R8 <- numeric(p)
for(i in 1:p)	R7[i] <- quantile(tnew.b[,i],0.025)
for(i in 1:p)	R8[i] <- quantile(tnew.b[,i],0.975)

R9 <- cbind(R1,R2,R3,R4)
colnames(R9) <- c("mean","sd","2.5th Q","97.5th Q")

R10 <- cbind(R5,R6,R7,R8)
colnames(R10) <- c("mean","sd","2.5th Q","97.5th Q")

R11 <- list(mu=mu.b,theta.new=tnew.b,mu_summary=R9,theta.new_summary=R10)

return(R11)

}


runif_tau <- function(y,S,B=10000,n.grid=10^4){

N <- dim(y)[1]
p <- dim(y)[2]

ftau2 <- function(g){

    G <- gmat(g,(g/2),p)
	
	C2 <- 1
	C3 <- 0
	C4 <- numeric(p)
	C5 <- matrix(numeric(p*p),p)
  
    for(i in 1:N){
      
      yi <- as.vector(y[i,])
      wi <- which(is.na(yi)==FALSE)
      pl <- length(wi)
      
      Si <- vmat(S[i,], p)
      
      yi <- yi[wi]
      Si <- pmat(Si,wi)
      Gi <- pmat(G,wi)
      
      A2 <- det(Gi+Si)^-0.5 
	  A3 <- t(yi)%*%ginv(Gi+Si)%*%yi
      A4 <- ginv(Gi + Si)%*%yi
      A5 <- ginv(Gi + Si)
	  
	  C2 <- C2*A2
	  C3 <- C3 + A3
	  C4 <- C4 + ivec(A4,wi,p)
	  C5 <- C5 + imat(A5,wi,p)
            
    }
    
	mu1 <- t(C4)%*%ginv(C5)
	Phi1 <- ginv(C5)
	
	Delta1 <- C3 - mu1%*%ginv(Phi1)%*%t(mu1)
	
	B1 <- sqrt(det(Phi1))
	B2 <- C2
	B3 <- exp(-0.5*Delta1)
	B4 <- 1/sqrt(g)

	B5 <- as.numeric(B1*B2*B3*B4)
	
	return(B5)
	
}


# 1段階目：荒いグリッドで探索を行い、サポートとなるレンジを絞り込む

h1 <- 0.01

x1 <- seq(0,10,by=h1)		# MDなど、スケールの大きな指標については、探索の上限を10から上げる必要があるだろう。
L1 <- length(x1)

y1 <- numeric(L1)

for(i in 1:L1)	y1[i] <- ftau2(x1[i])

xmax <- max(5, 100*x1[which.max(y1)])		# 次の探索範囲の上限（モードのあった点の100倍のポイント；カイ二乗分布とすると、ほとんどのケースで、99.999%点より、余裕をもって上）
h2 <- xmax/n.grid							# グリッドの単位


# 2段階目：絞り込まれたレンジで、細かいグリッドでの値を決める

x1 <- seq(0,xmax,by=h2)			# １段階目で設定された範囲で
L1 <- length(x1)

y1 <- y2 <- numeric(L1)

q10 <- as.numeric(round(quantile(1:L1,.1*1:10)))
count <- 10

for(i in 1:L1){
	y1[i] <- ftau2(x1[i])			# ここは並列計算にしたほうがいいのかな？？
	if(sum(i==q10)>0){
		print(paste0("The ",count," percents of the numerical integration is completed."))
		count <- count + 10
	}
}

# 累積分布関数の計算

if(y1[1]==Inf) y1[1] <- 0
y2[1] <- 0
for(i in 2:L1)	y2[i] <- y2[i-1] + 0.5*h1*(y1[i]+y1[i-1])

Z1 <- y2[L1]	# 正規化定数；台形公式に基づく

y2 <- y2/Z1

###

sp2 <- approxfun(y2,x1,method = "linear")		# 累積分布関数の逆関数を区分線形補完で作る

###

r1 <- runif(B,0,1)		# [0, 1] 上の一様乱数を、sp2に放り込むことで、tau2のサンプルを作ることができる
r2 <- sp2(r1)				# tau2 の周辺事後分布からのサンプル
r3 <- sqrt(r2)				# tau の周辺事後分布からのサンプル

R2 <- c(mean(r2),sd(r2),quantile(r2,c(.025,.975)))
R3 <- c(mean(r3),sd(r3),quantile(r3,c(.025,.975)))

R4 <- rbind(R2,R3)
colnames(R4) <- c("mean","sd","2.5th Q","97.5th Q")
rownames(R4) <- c("tau2","tau")

return(list(tau2=r2,tau=r3,post.summary=R4))

}


## version 0.0.0.9000

---

### NEWS.md setup

- added NEWS.md creation with newsmd

